local Renderer = require("renderer")
local Optimization = require("libraries.optimization")

local projectList = {"Pixel Art"}
local projectBlocks = {
    ["Pixel Art"] = { blocks = {}, gridSize = 16, preset = "black" }
}
local currentProjectName = "Pixel Art"
local gameState = "home"

local inputProjectName = ""
local cursorTimer = 0

local showColorPicker = false
local pickerColor = {r = 1, g = 0, b = 0}
local activeSlider = nil

local palette = {
    {r = 0, g = 0, b = 0},
    {r = 1, g = 1, b = 1},
    {r = 1, g = 0.1, b = 0.1},
    {r = 0.1, g = 0.9, b = 0.2},
    {r = 0.1, g = 0.4, b = 1},
    {r = 1, g = 0.9, b = 0.1}
}
local selectedColor = palette[1]
local blocks = {}

local paletteWidth = 70
local topBarHeight = 45
local boxSize = 40
local boxPadding = 10
local scrollY = 0

local saveMessageTimer = 0
local contextMenu = {visible = false, x = 0, y = 0, targetProject = nil}

function love.load()
    love.window.setMode(900, 600, {resizable = true})
    love.window.setTitle("Pixel Art")
    
    local p = projectBlocks[currentProjectName]
    blocks = p.blocks
    Renderer.selectedPixelSize = p.gridSize
    Renderer.selectedCanvasPreset = p.preset
end

function love.update(dt)
    cursorTimer = cursorTimer + dt
    if cursorTimer >= 1 then cursorTimer = 0 end
    
    if saveMessageTimer > 0 then
        saveMessageTimer = saveMessageTimer - dt
    end
    
    if showColorPicker and love.mouse.isDown(1) and activeSlider then
        local mx = love.mouse.getX()
        local mw = 280
        local px = love.graphics.getWidth() / 2 - mw / 2
        local val = math.max(0, math.min(1, (mx - (px + 45)) / 200))
        
        if activeSlider == "r" then
            pickerColor.r = val
        elseif activeSlider == "g" then
            pickerColor.g = val
        elseif activeSlider == "b" then
            pickerColor.b = val
        end
    end
end

function love.draw()
    if gameState == "home" then
        Renderer.drawHome(projectList, contextMenu, projectBlocks)
    elseif gameState == "creating" then
        Renderer.drawNamingModal(projectList, contextMenu, inputProjectName, cursorTimer, projectBlocks, "Create")
    elseif gameState == "editing_name" then
        Renderer.drawNamingModal(projectList, contextMenu, inputProjectName, cursorTimer, projectBlocks, "Save Changes")
    elseif gameState == "editor" then
        Renderer.drawGrid(paletteWidth, topBarHeight, Renderer.selectedPixelSize, Renderer.selectedCanvasPreset)
        Renderer.drawBlocks(blocks, paletteWidth, topBarHeight, Renderer.selectedPixelSize)
        Renderer.drawHover(paletteWidth, topBarHeight, Renderer.selectedPixelSize, selectedColor)
        Renderer.drawPalette(paletteWidth, topBarHeight, palette, selectedColor, boxSize, boxPadding, scrollY)
        Renderer.drawTopBar(topBarHeight, currentProjectName, saveMessageTimer, Renderer.selectedPixelSize)
        
        if showColorPicker then
            Renderer.drawColorPickerModal(pickerColor)
        end
    end
end

function love.mousereleased(x, y, button)
    if button == 1 then
        activeSlider = nil
    end
end

function love.mousepressed(x, y, button)
    if button == 1 then
        if gameState == "home" then
            if contextMenu.visible then
                if x >= contextMenu.x and x <= contextMenu.x + 120 and y >= contextMenu.y and y <= contextMenu.y + 60 then
                    if y < contextMenu.y + 30 then
                        gameState = "editing_name"
                        inputProjectName = contextMenu.targetProject
                        local p = projectBlocks[contextMenu.targetProject]
                        Renderer.selectedPixelSize = p.gridSize
                        Renderer.selectedCanvasPreset = p.preset
                    else
                        for i, p in ipairs(projectList) do
                            if p == contextMenu.targetProject then
                                table.remove(projectList, i)
                                projectBlocks[contextMenu.targetProject] = nil
                                break
                            end
                        end
                    end
                end
                contextMenu.visible = false
                return
            end
            
            if x >= 30 and x <= 210 and y >= 40 and y <= 80 then
                gameState = "creating"
                inputProjectName = ""
                Renderer.selectedPixelSize = 16
                Renderer.selectedCanvasPreset = "black"
                return
            end
            
            local startX, startY = 30, 175
            local cardW, cardH = 140, 140
            local gapX, gapY = 20, 20
            local cols = 6
            for i, pName in ipairs(projectList) do
                local col = (i - 1) % cols
                local row = math.floor((i - 1) / cols)
                local cX = startX + col * (cardW + gapX)
                local cY = startY + row * (cardH + gapY)
                if x >= cX and x <= cX + cardW and y >= cY and y <= cY + cardH then
                    currentProjectName = pName
                    local p = projectBlocks[pName]
                    if not p then 
                        p = {blocks = {}, gridSize = 16, preset = "black"}
                        projectBlocks[pName] = p
                    end
                    blocks = p.blocks
                    Renderer.selectedPixelSize = p.gridSize
                    Renderer.selectedCanvasPreset = p.preset
                    gameState = "editor"
                    return
                end
            end

        elseif gameState == "creating" or gameState == "editing_name" then
            local mw, mh = 340, 260
            local mx = love.graphics.getWidth() / 2 - mw / 2
            local my = love.graphics.getHeight() / 2 - mh / 2
            
            if x >= mx + 100 and x <= mx + 135 and y >= my + 100 and y <= my + 125 then
                Renderer.selectedPixelSize = math.max(2, Renderer.selectedPixelSize - 1)
            elseif x >= mx + 205 and x <= mx + 240 and y >= my + 100 and y <= my + 125 then
                Renderer.selectedPixelSize = math.min(64, Renderer.selectedPixelSize + 1)
            elseif x >= mx + 100 and x <= mx + 195 and y >= my + 140 and y <= my + 165 then
                Renderer.selectedCanvasPreset = "black"
            elseif x >= mx + 205 and x <= mx + 320 and y >= my + 140 and y <= my + 165 then
                Renderer.selectedCanvasPreset = "white"
            elseif x >= mx + 20 and x <= mx + 320 and y >= my + 205 and y <= my + 235 then
                if inputProjectName ~= "" then
                    if gameState == "creating" then
                        if not projectBlocks[inputProjectName] then
                            table.insert(projectList, inputProjectName)
                        end
                        blocks = {}
                        projectBlocks[inputProjectName] = {
                            blocks = blocks,
                            gridSize = Renderer.selectedPixelSize,
                            preset = Renderer.selectedCanvasPreset
                        }
                        currentProjectName = inputProjectName
                    else
                        for i, p in ipairs(projectList) do
                            if p == contextMenu.targetProject then
                                projectList[i] = inputProjectName
                                local oldData = projectBlocks[contextMenu.targetProject]
                                oldData.gridSize = Renderer.selectedPixelSize
                                oldData.preset = Renderer.selectedCanvasPreset
                                projectBlocks[inputProjectName] = oldData
                                
                                if contextMenu.targetProject ~= inputProjectName then
                                    projectBlocks[contextMenu.targetProject] = nil
                                end
                                break
                            end
                        end
                        currentProjectName = inputProjectName
                        blocks = projectBlocks[inputProjectName].blocks
                    end
                    gameState = "editor"
                end
            elseif x < mx or x > mx + mw or y < my or y > my + mh then
                gameState = "home"
                contextMenu.visible = false
            end

        elseif gameState == "editor" then
            if showColorPicker then
                local mw, mh = 280, 220
                local px = love.graphics.getWidth() / 2 - mw / 2
                local py = love.graphics.getHeight() / 2 - mh / 2
                
                if x >= px + 45 and x <= px + 245 then
                    if y >= py + 42 and y <= py + 72 then
                        activeSlider = "r"
                        return
                    elseif y >= py + 77 and y <= py + 107 then
                        activeSlider = "g"
                        return
                    elseif y >= py + 112 and y <= py + 142 then
                        activeSlider = "b"
                        return
                    end
                end
                
                if x >= px + 15 and x <= px + 90 and y >= py + 165 and y <= py + 197 then
                    local newColor = {r = pickerColor.r, g = pickerColor.g, b = pickerColor.b}
                    table.insert(palette, newColor)
                    selectedColor = newColor
                    showColorPicker = false
                elseif x >= px + 100 and x <= px + 175 and y >= py + 165 and y <= py + 197 then
                    if #palette > 1 then
                        for i, col in ipairs(palette) do
                            if col.r == selectedColor.r and col.g == selectedColor.g and col.b == selectedColor.b then
                                table.remove(palette, i)
                                selectedColor = palette[math.max(1, i - 1)]
                                break
                            end
                        end
                    end
                    showColorPicker = false
                elseif x >= px + 185 and x <= px + 265 and y >= py + 165 and y <= py + 197 then
                    showColorPicker = false
                end
                return
            end
            
            if y < topBarHeight then
                if x >= 15 and x <= 95 and y >= 8 and y <= 36 then
                    gameState = "home"
                    contextMenu.visible = false
                elseif x >= 105 and x <= 185 and y >= 8 and y <= 36 then
                    Optimization.removeDuplicates(blocks)
                    projectBlocks[currentProjectName].blocks = blocks
                    projectBlocks[currentProjectName].gridSize = Renderer.selectedPixelSize
                    projectBlocks[currentProjectName].preset = Renderer.selectedCanvasPreset
                    saveMessageTimer = 2
                elseif x >= 195 and x <= 275 and y >= 8 and y <= 36 then
                    blocks = {}
                elseif x >= 285 and x <= 375 and y >= 8 and y <= 36 then
                    Renderer.selectedPixelSize = Renderer.selectedPixelSize + 1
                    if Renderer.selectedPixelSize > 64 then Renderer.selectedPixelSize = 4 end
                end
            elseif x < paletteWidth then
                for i, col in ipairs(palette) do
                    local boxY = topBarHeight + boxPadding + (i - 1) * (boxSize + boxPadding) + scrollY
                    if x >= 10 and x <= 10 + boxSize and y >= boxY and y <= boxY + boxSize then
                        selectedColor = col
                        return
                    end
                end
                local plusY = topBarHeight + boxPadding + #palette * (boxSize + boxPadding) + scrollY
                if x >= 10 and x <= 10 + boxSize and y >= plusY and y <= plusY + boxSize then
                    pickerColor = {r = selectedColor.r, g = selectedColor.g, b = selectedColor.b}
                    showColorPicker = true
                end
            else
                local gridCol = math.floor((x - paletteWidth) / Renderer.selectedPixelSize)
                local gridRow = math.floor((y - topBarHeight) / Renderer.selectedPixelSize)
                
                local found = false
                for i, b in ipairs(blocks) do
                    if b.col == gridCol and b.row == gridRow then
                        table.remove(blocks, i)
                        found = true
                        break
                    end
                end
                if not found then
                    table.insert(blocks, {
                        col = gridCol, 
                        row = gridRow, 
                        color = {r = selectedColor.r, g = selectedColor.g, b = selectedColor.b}
                    })
                end
            end
        end
    elseif button == 2 then
        if gameState == "home" then
            local startX, startY = 30, 175
            local cardW, cardH = 140, 140
            local gapX, gapY = 20, 20
            local cols = 6
            for i, pName in ipairs(projectList) do
                local col = (i - 1) % cols
                local row = math.floor((i - 1) / cols)
                local cX = startX + col * (cardW + gapX)
                local cY = startY + row * (cardH + gapY)
                if x >= cX and x <= cX + cardW and y >= cY and y <= cY + cardH then
                    contextMenu.visible = true
                    contextMenu.x = x
                    contextMenu.y = y
                    contextMenu.targetProject = pName
                    return
                end
            end
            contextMenu.visible = false
        end
    end
end

function love.wheelmoved(x, y)
    if gameState == "editor" and love.mouse.getX() < paletteWidth then
        scrollY = scrollY + y * 20
        local totalHeight = (#palette + 1) * (boxSize + boxPadding) + boxPadding
        local minScroll = math.min(0, love.graphics.getHeight() - topBarHeight - totalHeight)
        scrollY = math.max(minScroll, math.min(0, scrollY))
    end
end

function love.textinput(t)
    if gameState == "creating" or gameState == "editing_name" then
        inputProjectName = inputProjectName .. t
    end
end

function love.keypressed(key)
    if gameState == "creating" or gameState == "editing_name" then
        if key == "backspace" then
            inputProjectName = string.sub(inputProjectName, 1, -2)
        elseif key == "return" then
            if inputProjectName ~= "" then
                if gameState == "creating" then
                    if not projectBlocks[inputProjectName] then
                        table.insert(projectList, inputProjectName)
                    end
                    blocks = {}
                    projectBlocks[inputProjectName] = {
                        blocks = blocks,
                        gridSize = Renderer.selectedPixelSize,
                        preset = Renderer.selectedCanvasPreset
                    }
                    currentProjectName = inputProjectName
                else
                    for i, p in ipairs(projectList) do
                        if p == contextMenu.targetProject then
                            projectList[i] = inputProjectName
                            local oldData = projectBlocks[contextMenu.targetProject]
                            oldData.gridSize = Renderer.selectedPixelSize
                            oldData.preset = Renderer.selectedCanvasPreset
                            projectBlocks[inputProjectName] = oldData
                            
                            if contextMenu.targetProject ~= inputProjectName then
                                projectBlocks[contextMenu.targetProject] = nil
                            end
                            break
                        end
                    end
                    currentProjectName = inputProjectName
                    blocks = projectBlocks[inputProjectName].blocks
                end
                gameState = "editor"
            end
        end
    end
end