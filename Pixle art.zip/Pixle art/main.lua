local Renderer = require("renderer")

local currentState = "home" -- "home", "namingModal", "editor", "colorPicker"
local projectList = {}
local projectBlocks = {}
local currentProjectName = ""
local placedBlocks = {}

-- Editor Settings
local paletteWidth = 60
local topBarHeight = 44
local pixelW = 16
local pixelH = 16
local scrollY = 0
local boxSize = 40
local boxPadding = 10

-- Modal & Input State
local inputProjectName = ""
local cursorTimer = 0
local saveMessageTimer = 0
local buttonLabel = "Create"
local editingProjectIndex = nil

-- Context Menu
local contextMenu = { visible = false, x = 0, y = 0, projectIndex = nil }

-- Palette Colors
local paletteColors = {
    { r = 1, g = 0.2, b = 0.2 },
    { r = 0.2, g = 0.8, b = 0.2 },
    { r = 0.2, g = 0.5, b = 1.0 },
    { r = 1, g = 0.9, b = 0.2 },
    { r = 0.9, g = 0.3, b = 0.9 },
    { r = 1, g = 1, b = 1 },
    { r = 0, g = 0, b = 0 }
}
local selectedColor = paletteColors[1]
local pickerColor = { r = 0.5, g = 0.5, b = 0.5 }
local draggingSlider = nil

function love.load()
    love.window.setTitle("Pixel Art Studio")
    love.window.setMode(1000, 700, { resizable = true })
    love.keyboard.setKeyRepeat(true)
end

function love.update(dt)
    cursorTimer = (cursorTimer + dt) % 1.0
    if saveMessageTimer > 0 then
        saveMessageTimer = saveMessageTimer - dt
    end

    if currentState == "editor" and love.mouse.isDown(1, 2) then
        local mx, my = love.mouse.getPosition()
        if mx > paletteWidth and my > topBarHeight then
            local col = math.floor((mx - paletteWidth) / pixelW)
            local row = math.floor((my - topBarHeight) / pixelH)
            
            if love.mouse.isDown(1) then
                local found = false
                for _, b in ipairs(placedBlocks) do
                    if b.col == col and b.row == row then
                        b.color = selectedColor
                        found = true
                        break
                    end
                end
                if not found then
                    table.insert(placedBlocks, { col = col, row = row, color = selectedColor })
                end
            elseif love.mouse.isDown(2) then
                for i = #placedBlocks, 1, -1 do
                    if placedBlocks[i].col == col and placedBlocks[i].row == row then
                        table.remove(placedBlocks, i)
                    end
                end
            end
        end
    end

    if currentState == "colorPicker" and draggingSlider and love.mouse.isDown(1) then
        local mx = love.mouse.getPosition()
        local mw = 280
        local startX = love.graphics.getWidth() / 2 - mw / 2 + 45
        local val = math.max(0, math.min(1, (mx - startX) / 200))
        pickerColor[draggingSlider] = val
    end
end

function love.draw()
    if currentState == "home" then
        Renderer.drawHome(projectList, contextMenu, projectBlocks)
    elseif currentState == "namingModal" then
        Renderer.drawNamingModal(projectList, contextMenu, inputProjectName, cursorTimer, projectBlocks, buttonLabel)
    elseif currentState == "editor" or currentState == "colorPicker" then
        Renderer.drawGrid(paletteWidth, topBarHeight, pixelW, pixelH, Renderer.selectedCanvasPreset)
        Renderer.drawBlocks(placedBlocks, paletteWidth, topBarHeight, pixelW, pixelH)
        Renderer.drawHover(paletteWidth, topBarHeight, pixelW, pixelH, selectedColor)
        Renderer.drawPalette(paletteWidth, topBarHeight, paletteColors, selectedColor, boxSize, boxPadding, scrollY)
        Renderer.drawTopBar(topBarHeight, currentProjectName, saveMessageTimer, pixelW, pixelH)
        
        if currentState == "colorPicker" then
            Renderer.drawColorPickerModal(pickerColor)
        end
    end
end

function love.mousepressed(x, y, button)
    if currentState == "home" then
        if contextMenu.visible and button == 1 then
            local cmX, cmY = contextMenu.x, contextMenu.y
            if x >= cmX and x <= cmX + 120 then
                -- Edit Project Settings
                if y >= cmY + 5 and y <= cmY + 30 then
                    editingProjectIndex = contextMenu.projectIndex
                    inputProjectName = projectList[editingProjectIndex]
                    local pData = projectBlocks[inputProjectName] or {}
                    Renderer.selectedPixelW = pData.pixelW or 16
                    Renderer.selectedPixelH = pData.pixelH or 16
                    Renderer.selectedCanvasPreset = pData.preset or "black"
                    buttonLabel = "Save Changes"
                    currentState = "namingModal"
                    contextMenu.visible = false
                    return
                -- Delete Project
                elseif y >= cmY + 30 and y <= cmY + 55 then
                    local delName = projectList[contextMenu.projectIndex]
                    table.remove(projectList, contextMenu.projectIndex)
                    projectBlocks[delName] = nil
                    contextMenu.visible = false
                    return
                end
            end
            contextMenu.visible = false
            return
        end

        contextMenu.visible = false

        -- New Project Button
        if button == 1 and x >= 30 and x <= 210 and y >= 40 and y <= 80 then
            inputProjectName = "Project " .. (#projectList + 1)
            Renderer.selectedPixelW = 16
            Renderer.selectedPixelH = 16
            Renderer.selectedCanvasPreset = "black"
            buttonLabel = "Create"
            editingProjectIndex = nil
            currentState = "namingModal"
            return
        end

        -- Project Card Selection
        local startX, startY = 30, 175
        local cardW, cardH = 140, 140
        local gapX, gapY = 20, 20
        local cols = 6

        for i, pName in ipairs(projectList) do
            local col = (i - 1) % cols
            local row = math.floor((i - 1) / cols)
            local cX = startX + col * (cardW + gapX)
            local cY = startY + row * (cardH + gapY)

            if x >= cX and x <= cX + cardW and y >= cY and y <= cY + cardH then
                if button == 1 then
                    currentProjectName = pName
                    local pData = projectBlocks[pName] or { blocks = {}, pixelW = 16, pixelH = 16, preset = "black" }
                    placedBlocks = pData.blocks
                    pixelW = pData.pixelW or 16
                    pixelH = pData.pixelH or 16
                    Renderer.selectedCanvasPreset = pData.preset or "black"
                    currentState = "editor"
                    return
                elseif button == 2 then
                    contextMenu.visible = true
                    contextMenu.x = x
                    contextMenu.y = y
                    contextMenu.projectIndex = i
                    return
                end
            end
        end

    elseif currentState == "namingModal" then
        local mw, mh = 360, 310
        local mx = love.graphics.getWidth() / 2 - mw / 2
        local my = love.graphics.getHeight() / 2 - mh / 2

        if button == 1 then
            -- Pixel Width Controls (-1 / +1)
            if x >= mx + 130 and x <= mx + 160 and y >= my + 100 and y <= my + 125 then
                Renderer.selectedPixelW = math.max(1, Renderer.selectedPixelW - 1)
            elseif x >= mx + 230 and x <= mx + 260 and y >= my + 100 and y <= my + 125 then
                Renderer.selectedPixelW = math.min(128, Renderer.selectedPixelW + 1)

            -- Pixel Height Controls (-1 / +1)
            elseif x >= mx + 130 and x <= mx + 160 and y >= my + 140 and y <= my + 165 then
                Renderer.selectedPixelH = math.max(1, Renderer.selectedPixelH - 1)
            elseif x >= mx + 230 and x <= mx + 260 and y >= my + 140 and y <= my + 165 then
                Renderer.selectedPixelH = math.min(128, Renderer.selectedPixelH + 1)
            
            -- Preset Select
            elseif x >= mx + 120 and x <= mx + 185 and y >= my + 185 and y <= my + 210 then
                Renderer.selectedCanvasPreset = "black"
            elseif x >= mx + 192 and x <= mx + 257 and y >= my + 185 and y <= my + 210 then
                Renderer.selectedCanvasPreset = "white"
            elseif x >= mx + 264 and x <= mx + 339 and y >= my + 185 and y <= my + 210 then
                Renderer.selectedCanvasPreset = "transparent"

            -- Submit Button (Create / Save)
            elseif x >= mx + 20 and x <= mx + 340 and y >= my + 245 and y <= my + 280 then
                if inputProjectName ~= "" then
                    if editingProjectIndex then
                        local oldName = projectList[editingProjectIndex]
                        projectList[editingProjectIndex] = inputProjectName
                        local existingBlocks = projectBlocks[oldName] and projectBlocks[oldName].blocks or {}
                        projectBlocks[inputProjectName] = {
                            blocks = existingBlocks,
                            pixelW = Renderer.selectedPixelW,
                            pixelH = Renderer.selectedPixelH,
                            preset = Renderer.selectedCanvasPreset
                        }
                        if oldName ~= inputProjectName then projectBlocks[oldName] = nil end
                    else
                        table.insert(projectList, inputProjectName)
                        projectBlocks[inputProjectName] = {
                            blocks = {},
                            pixelW = Renderer.selectedPixelW,
                            pixelH = Renderer.selectedPixelH,
                            preset = Renderer.selectedCanvasPreset
                        }
                    end
                    currentProjectName = inputProjectName
                    placedBlocks = projectBlocks[inputProjectName].blocks
                    pixelW = Renderer.selectedPixelW
                    pixelH = Renderer.selectedPixelH
                    currentState = "editor"
                end
            end
        end

    elseif currentState == "editor" then
        if button == 1 then
            if y <= topBarHeight then
                -- Home
                if x >= 15 and x <= 80 then
                    projectBlocks[currentProjectName] = {
                        blocks = placedBlocks,
                        pixelW = pixelW,
                        pixelH = pixelH,
                        preset = Renderer.selectedCanvasPreset
                    }
                    currentState = "home"
                -- Save PNG directly to Downloads
                elseif x >= 90 and x <= 175 then
                    projectBlocks[currentProjectName] = {
                        blocks = placedBlocks,
                        pixelW = pixelW,
                        pixelH = pixelH,
                        preset = Renderer.selectedCanvasPreset
                    }
                    Renderer.exportPNG(placedBlocks, pixelW, pixelH, Renderer.selectedCanvasPreset, currentProjectName .. ".png")
                    saveMessageTimer = 2.0
                -- Clear
                elseif x >= 185 and x <= 240 then
                    placedBlocks = {}
                -- Decrease Pixel Dimensions (-1)
                elseif x >= 250 and x <= 272 then
                    pixelW = math.max(1, pixelW - 1)
                    pixelH = math.max(1, pixelH - 1)
                -- Increase Pixel Dimensions (+1)
                elseif x >= 335 and x <= 357 then
                    pixelW = math.min(128, pixelW + 1)
                    pixelH = math.min(128, pixelH + 1)
                end
                return
            end

            -- Palette Clicks
            if x <= paletteWidth and y > topBarHeight then
                for i, col in ipairs(paletteColors) do
                    local boxY = topBarHeight + boxPadding + (i - 1) * (boxSize + boxPadding) + scrollY
                    if y >= boxY and y <= boxY + boxSize then
                        selectedColor = col
                        return
                    end
                end

                local plusY = topBarHeight + boxPadding + #paletteColors * (boxSize + boxPadding) + scrollY
                if y >= plusY and y <= plusY + boxSize then
                    pickerColor = { r = selectedColor.r, g = selectedColor.g, b = selectedColor.b }
                    currentState = "colorPicker"
                    return
                end
            end
        end

    elseif currentState == "colorPicker" then
        local mw, mh = 280, 220
        local mx = love.graphics.getWidth() / 2 - mw / 2
        local my = love.graphics.getHeight() / 2 - mh / 2

        if button == 1 then
            if x >= mx + 45 and x <= mx + 245 then
                if y >= my + 52 and y <= my + 68 then draggingSlider = "r"
                elseif y >= my + 87 and y <= my + 103 then draggingSlider = "g"
                elseif y >= my + 122 and y <= my + 138 then draggingSlider = "b" end
            end

            if y >= my + 165 and y <= my + 197 then
                if x >= mx + 15 and x <= mx + 90 then
                    local newCol = { r = pickerColor.r, g = pickerColor.g, b = pickerColor.b }
                    table.insert(paletteColors, newCol)
                    selectedColor = newCol
                    currentState = "editor"
                elseif x >= mx + 100 and x <= mx + 175 then
                    if #paletteColors > 1 then
                        for i, col in ipairs(paletteColors) do
                            if col == selectedColor then
                                table.remove(paletteColors, i)
                                selectedColor = paletteColors[1]
                                break
                            end
                        end
                    end
                    currentState = "editor"
                elseif x >= mx + 185 and x <= mx + 265 then
                    currentState = "editor"
                end
            end
        end
    end
end

function love.mousereleased(x, y, button)
    draggingSlider = nil
end

function love.wheelmoved(x, y)
    if currentState == "editor" and love.mouse.getX() <= paletteWidth then
        scrollY = math.min(0, scrollY + y * 20)
    end
end

function love.textinput(t)
    if currentState == "namingModal" then
        inputProjectName = inputProjectName .. t
    end
end

function love.keypressed(key)
    if currentState == "namingModal" then
        if key == "backspace" then
            inputProjectName = inputProjectName:sub(1, -2)
        elseif key == "return" then
            if inputProjectName ~= "" then
                table.insert(projectList, inputProjectName)
                projectBlocks[inputProjectName] = {
                    blocks = {},
                    pixelW = Renderer.selectedPixelW,
                    pixelH = Renderer.selectedPixelH,
                    preset = Renderer.selectedCanvasPreset
                }
                currentProjectName = inputProjectName
                placedBlocks = {}
                pixelW = Renderer.selectedPixelW
                pixelH = Renderer.selectedPixelH
                currentState = "editor"
            end
        end
    end
end