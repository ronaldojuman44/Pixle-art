local Optimization = {}

local isDirty = true
local canvasCache = nil

function Optimization.markDirty()
    isDirty = true
end

function Optimization.isDirty()
    return isDirty
end

function Optimization.removeDuplicates(blocks)
    local seen = {}
    for i = #blocks, 1, -1 do
        local col = blocks[i].col or 0
        local row = blocks[i].row or 0
        local key = col .. "," .. row
        if seen[key] then
            table.remove(blocks, i)
        else
            seen[key] = true
        end
    end
end

function Optimization.isBlockVisible(block, paletteWidth, topBarHeight, windowWidth, windowHeight, gridSize)
    local bx = block.col and (paletteWidth + block.col * gridSize) or (block.x or 0)
    local by = block.row and (topBarHeight + block.row * gridSize) or (block.y or 0)
    
    return bx + gridSize > paletteWidth 
       and bx < windowWidth 
       and by + gridSize > topBarHeight 
       and by < windowHeight
end

function Optimization.drawCachedCanvas(width, height, drawCallback)
    if not canvasCache or canvasCache:getWidth() ~= width or canvasCache:getHeight() ~= height then
        canvasCache = love.graphics.newCanvas(width, height)
        isDirty = true
    end

    if isDirty then
        love.graphics.setCanvas(canvasCache)
        love.graphics.clear(0, 0, 0, 0)
        drawCallback()
        love.graphics.setCanvas()
        isDirty = false
    end

    love.graphics.setBlendMode("alpha", "premultiplied")
    love.graphics.draw(canvasCache, 0, 0)
    love.graphics.setBlendMode("alpha")
end

return Optimization