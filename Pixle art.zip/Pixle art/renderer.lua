local Optimization = require("libraries.optimization")
local Renderer = {} -- This line creates the Renderer so it doesn't return a nil value error!

Renderer.selectedCanvasPreset = "black"
Renderer.selectedPixelSize = 16

function Renderer.drawHome(projectList, contextMenu, projectBlocks)
    love.graphics.clear(0.12, 0.14, 0.18)
    
    love.graphics.setColor(0.16, 0.18, 0.24)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), 120)
    
    love.graphics.setColor(0.2, 0.6, 0.9)
    love.graphics.rectangle("fill", 30, 40, 180, 40, 6, 6)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("+ New Project", 52, 52)
    
    love.graphics.setColor(0.6, 0.65, 0.75)
    love.graphics.print("YOUR PROJECTS", 30, 140)
    
    local startX, startY = 30, 175
    local cardW, cardH = 140, 140
    local gapX, gapY = 20, 20
    local cols = 6
    
    for i, pName in ipairs(projectList) do
        local col = (i - 1) % cols
        local row = math.floor((i - 1) / cols)
        local cX = startX + col * (cardW + gapX)
        local cY = startY + row * (cardH + gapY)
        
        love.graphics.setColor(0.18, 0.2, 0.27)
        love.graphics.rectangle("fill", cX, cY, cardW, cardH, 8, 8)
        love.graphics.setColor(0.28, 0.32, 0.42)
        love.graphics.rectangle("line", cX, cY, cardW, cardH, 8, 8)
        
        local pData = projectBlocks[pName]
        local pBlocks = pData and pData.blocks or {}
        
        if pData and pData.preset == "white" then
            love.graphics.setColor(0.92, 0.92, 0.95)
        else
            love.graphics.setColor(0.08, 0.09, 0.12)
        end
        love.graphics.rectangle("fill", cX + 15, cY + 15, 110, 80, 4, 4)
        
        local scaleRatio = 110 / 830 
        local previewGridSize = math.max(0.5, (pData and pData.gridSize or 16) * scaleRatio)
        
        for _, block in ipairs(pBlocks) do
            local px = cX + 15 + block.col * previewGridSize
            local py = cY + 15 + block.row * previewGridSize
            
            if px >= cX + 15 and px + previewGridSize <= cX + 125 and py >= cY + 15 and py + previewGridSize <= cY + 95 then
                love.graphics.setColor(block.color.r, block.color.g, block.color.b)
                love.graphics.rectangle("fill", px, py, previewGridSize, previewGridSize)
            end
        end
        
        love.graphics.setColor(0.9, 0.9, 0.95)
        love.graphics.print(pName, cX + 15, cY + 108)
    end
    
    if contextMenu.visible then
        local cmX, cmY = contextMenu.x, contextMenu.y
        local menuW, menuH = 120, 60
        love.graphics.setColor(0.14, 0.16, 0.22)
        love.graphics.rectangle("fill", cmX, cmY, menuW, menuH, 6, 6)
        love.graphics.setColor(0.3, 0.35, 0.45)
        love.graphics.rectangle("line", cmX, cmY, menuW, menuH, 6, 6)
        love.graphics.setColor(0.9, 0.9, 0.9)
        love.graphics.print("Edit", cmX + 15, cmY + 10)
        love.graphics.setColor(1, 0.3, 0.3)
        love.graphics.print("Delete", cmX + 15, cmY + 35)
    end
end

function Renderer.drawNamingModal(projectList, contextMenu, inputProjectName, cursorTimer, projectBlocks, buttonLabel)
    Renderer.drawHome(projectList, contextMenu, projectBlocks)
    
    love.graphics.setColor(0, 0, 0, 0.7)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
    
    local mw, mh = 340, 260
    local mx = love.graphics.getWidth() / 2 - mw / 2
    local my = love.graphics.getHeight() / 2 - mh / 2
    
    love.graphics.setColor(0.16, 0.18, 0.25)
    love.graphics.rectangle("fill", mx, my, mw, mh, 8, 8)
    love.graphics.setColor(0.3, 0.35, 0.45)
    love.graphics.rectangle("line", mx, my, mw, mh, 8, 8)
    
    love.graphics.setColor(1, 1, 1)
    love.graphics.print(buttonLabel == "Save Changes" and "Edit Project" or "Create Project", mx + 20, my + 20)
    
    love.graphics.setColor(0.1, 0.11, 0.15)
    love.graphics.rectangle("fill", mx + 20, my + 55, 300, 32, 4, 4)
    love.graphics.setColor(0.9, 0.9, 0.95)
    local displayName = inputProjectName .. (cursorTimer < 0.5 and "|" or "")
    love.graphics.print(displayName, mx + 30, my + 63)
    
    love.graphics.setColor(0.7, 0.75, 0.85)
    love.graphics.print("Grid Size:", mx + 20, my + 105)
    love.graphics.setColor(0.25, 0.28, 0.35)
    love.graphics.rectangle("fill", mx + 100, my + 100, 35, 25, 4, 4)
    love.graphics.rectangle("fill", mx + 205, my + 100, 35, 25, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("<", mx + 112, my + 104)
    love.graphics.print(">", mx + 217, my + 104)
    love.graphics.print(Renderer.selectedPixelSize .. "px", mx + 153, my + 104)
    
    love.graphics.setColor(0.7, 0.75, 0.85)
    love.graphics.print("Canvas:", mx + 20, my + 145)
    local isBlack = Renderer.selectedCanvasPreset == "black"
    love.graphics.setColor(isBlack and 0.2 or 0.15, isBlack and 0.5 or 0.17, isBlack and 0.8 or 0.2)
    love.graphics.rectangle("fill", mx + 100, my + 140, 95, 25, 4, 4)
    local isWhite = Renderer.selectedCanvasPreset == "white"
    love.graphics.setColor(isWhite and 0.2 or 0.15, isWhite and 0.5 or 0.17, isWhite and 0.8 or 0.2)
    love.graphics.rectangle("fill", mx + 205, my + 140, 115, 25, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Black", mx + 130, my + 144)
    love.graphics.print("White", mx + 242, my + 144)
    
    local btnX, btnY, btnW, btnH = mx + 20, my + 205, 300, 30
    love.graphics.setColor(0.2, 0.6, 0.3)
    love.graphics.rectangle("fill", btnX, btnY, btnW, btnH, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print(buttonLabel or "Create", btnX + 120, btnY + 7)
end

function Renderer.drawGrid(paletteWidth, topBarHeight, gridSize, preset)
    if preset == "white" then
        love.graphics.clear(0.92, 0.92, 0.95)
        love.graphics.setColor(0.82, 0.82, 0.85)
    else
        love.graphics.clear(0.1, 0.1, 0.12)
        love.graphics.setColor(0.18, 0.18, 0.22)
    end
    
    local w = love.graphics.getWidth()
    local h = love.graphics.getHeight()
    for x = paletteWidth, w, gridSize do
        love.graphics.line(x, topBarHeight, x, h)
    end
    for y = topBarHeight, h, gridSize do
        love.graphics.line(paletteWidth, y, w, y)
    end
end

function Renderer.drawBlocks(blocks, paletteWidth, topBarHeight, gridSize)
    local ww = love.graphics.getWidth()
    local wh = love.graphics.getHeight()
    
    for _, block in ipairs(blocks) do
        if Optimization.isBlockVisible(block, paletteWidth, topBarHeight, ww, wh, gridSize) then
            local bx = paletteWidth + block.col * gridSize
            local by = topBarHeight + block.row * gridSize
            love.graphics.setColor(block.color.r, block.color.g, block.color.b)
            love.graphics.rectangle("fill", bx, by, gridSize, gridSize)
        end
    end
end

function Renderer.drawHover(paletteWidth, topBarHeight, gridSize, color)
    local mx, my = love.mouse.getPosition()
    if mx > paletteWidth and my > topBarHeight then
        local col = math.floor((mx - paletteWidth) / gridSize)
        local row = math.floor((my - topBarHeight) / gridSize)
        local gx = paletteWidth + col * gridSize
        local gy = topBarHeight + row * gridSize
        love.graphics.setColor(color.r, color.g, color.b, 0.4)
        love.graphics.rectangle("fill", gx, gy, gridSize, gridSize)
    end
end

function Renderer.drawPalette(paletteWidth, topBarHeight, colors, selectedColor, boxSize, boxPadding, scrollY)
    love.graphics.setColor(0.14, 0.15, 0.18)
    love.graphics.rectangle("fill", 0, topBarHeight, paletteWidth, love.graphics.getHeight() - topBarHeight)
    love.graphics.setColor(0.2, 0.22, 0.26)
    love.graphics.line(paletteWidth, topBarHeight, paletteWidth, love.graphics.getHeight())
    
    for i, col in ipairs(colors) do
        local boxY = topBarHeight + boxPadding + (i - 1) * (boxSize + boxPadding) + scrollY
        if boxY + boxSize > topBarHeight and boxY < love.graphics.getHeight() then
            if col == selectedColor then
                love.graphics.setColor(1, 1, 1)
                love.graphics.rectangle("fill", 10 - 3, boxY - 3, boxSize + 6, boxSize + 6, 4, 4)
            end
            love.graphics.setColor(col.r, col.g, col.b)
            love.graphics.rectangle("fill", 10, boxY, boxSize, boxSize, 3, 3)
        end
    end
    
    local plusY = topBarHeight + boxPadding + #colors * (boxSize + boxPadding) + scrollY
    if plusY + boxSize > topBarHeight and plusY < love.graphics.getHeight() then
        love.graphics.setColor(0.22, 0.25, 0.32)
        love.graphics.rectangle("fill", 10, plusY, boxSize, boxSize, 4, 4)
        love.graphics.setColor(0.35, 0.4, 0.5)
        love.graphics.rectangle("line", 10, plusY, boxSize, boxSize, 4, 4)
        love.graphics.setColor(0.9, 0.95, 1)
        love.graphics.print("+", 25, plusY + 12)
    end
end

function Renderer.drawColorPickerModal(pickerColor)
    love.graphics.setColor(0, 0, 0, 0.6)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
    
    local mw, mh = 280, 220
    local mx = love.graphics.getWidth() / 2 - mw / 2
    local my = love.graphics.getHeight() / 2 - mh / 2
    
    love.graphics.setColor(0.16, 0.18, 0.24)
    love.graphics.rectangle("fill", mx, my, mw, mh, 8, 8)
    love.graphics.setColor(0.3, 0.35, 0.45)
    love.graphics.rectangle("line", mx, my, mw, mh, 8, 8)
    
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Pick a Color", mx + 15, my + 15)
    
    love.graphics.setColor(pickerColor.r, pickerColor.g, pickerColor.b)
    love.graphics.rectangle("fill", mx + 200, my + 12, 60, 24, 4, 4)
    love.graphics.setColor(0.25, 0.28, 0.35)
    love.graphics.rectangle("line", mx + 200, my + 12, 60, 24, 4, 4)
    
    local sliderConfigs = {
        {label = "R:", val = pickerColor.r, y = my + 52, color = {1, 0.3, 0.3}},
        {label = "G:", val = pickerColor.g, y = my + 87, color = {0.3, 1, 0.3}},
        {label = "B:", val = pickerColor.b, y = my + 122, color = {0.3, 0.5, 1}}
    }
    
    for _, s in ipairs(sliderConfigs) do
        love.graphics.setColor(unpack(s.color))
        love.graphics.print(s.label, mx + 20, s.y + 3)
        
        love.graphics.setColor(0.1, 0.12, 0.16)
        love.graphics.rectangle("fill", mx + 45, s.y + 6, 200, 8, 4, 4)
        
        love.graphics.setColor(unpack(s.color))
        love.graphics.rectangle("fill", mx + 45, s.y + 6, 200 * s.val, 8, 4, 4)
        
        local thumbX = mx + 45 + 200 * s.val
        local thumbY = s.y + 10
        
        love.graphics.setColor(0.2, 0.5, 0.9)
        love.graphics.circle("fill", thumbX, thumbY, 10)
        love.graphics.setColor(1, 1, 1)
        love.graphics.circle("fill", thumbX, thumbY, 4)
    end
    
    love.graphics.setColor(0.2, 0.6, 0.3)
    love.graphics.rectangle("fill", mx + 15, my + 165, 75, 32, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Add", mx + 40, my + 173)
    
    love.graphics.setColor(0.8, 0.25, 0.25)
    love.graphics.rectangle("fill", mx + 100, my + 165, 75, 32, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Remove", mx + 115, my + 173)

    love.graphics.setColor(0.3, 0.35, 0.4)
    love.graphics.rectangle("fill", mx + 185, my + 165, 80, 32, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Cancel", mx + 205, my + 173)
end

function Renderer.drawTopBar(topBarHeight, currentProjectName, saveMessageTimer, gridSize)
    love.graphics.setColor(0.12, 0.13, 0.16)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), topBarHeight)
    love.graphics.setColor(0.2, 0.22, 0.26)
    love.graphics.line(0, topBarHeight, love.graphics.getWidth(), topBarHeight)
    
    love.graphics.setColor(0.25, 0.28, 0.35)
    love.graphics.rectangle("fill", 15, 8, 80, 28, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("< Home", 28, 14)
    
    love.graphics.setColor(0.2, 0.5, 0.9)
    love.graphics.rectangle("fill", 105, 8, 80, 28, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Save", 130, 14)
    
    love.graphics.setColor(0.8, 0.25, 0.25)
    love.graphics.rectangle("fill", 195, 8, 80, 28, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Clear", 218, 14)
    
    love.graphics.setColor(0.2, 0.25, 0.35)
    love.graphics.rectangle("fill", 285, 8, 90, 28, 4, 4)
    love.graphics.setColor(0.8, 0.85, 0.95)
    love.graphics.print("Grid: " .. gridSize .. "px", 298, 14)
    
    local font = love.graphics.getFont()
    local titleW = font:getWidth(currentProjectName)
    love.graphics.setColor(0.9, 0.9, 0.95)
    love.graphics.print(currentProjectName, math.floor((love.graphics.getWidth() - titleW) / 2), 14)
    
    if saveMessageTimer > 0 then
        local msgW = font:getWidth("Project Saved!")
        love.graphics.setColor(0.2, 0.8, 0.4)
        love.graphics.print("Project Saved!", love.graphics.getWidth() - msgW - 15, 14)
    end
end

return Renderer