local Renderer = {}

Renderer.selectedPixelW = 16
Renderer.selectedPixelH = 16
Renderer.selectedCanvasPreset = "black"

-- 1. Draw Home Screen
function Renderer.drawHome(projectList, contextMenu, projectBlocks)
    love.graphics.clear(0.12, 0.12, 0.15)

    -- Header / New Project Button
    love.graphics.setColor(0.2, 0.6, 1)
    love.graphics.rectangle("fill", 30, 40, 180, 40, 6, 6)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("+ New Project", 65, 52)

    -- Title
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Your Projects", 30, 110)

    -- Project Grid
    local startX, startY = 30, 175
    local cardW, cardH = 140, 140
    local gapX, gapY = 20, 20
    local cols = 6

    for i, pName in ipairs(projectList) do
        local col = (i - 1) % cols
        local row = math.floor((i - 1) / cols)
        local cX = startX + col * (cardW + gapX)
        local cY = startY + row * (cardH + gapY)

        -- Card Background
        love.graphics.setColor(0.2, 0.22, 0.26)
        love.graphics.rectangle("fill", cX, cY, cardW, cardH, 8, 8)

        local pData = projectBlocks[pName] or {}
        local bgPreset = pData.preset or "black"

        -- Preview Box Background based on project settings
        if bgPreset == "white" then
            love.graphics.setColor(0.92, 0.92, 0.92)
        elseif bgPreset == "transparent" then
            love.graphics.setColor(0.15, 0.15, 0.18)
        else
            love.graphics.setColor(0.08, 0.08, 0.1)
        end
        love.graphics.rectangle("fill", cX + 10, cY + 10, 120, 90, 4, 4)

        -- Draw mini preview blocks
        if pData and pData.blocks then
            love.graphics.setScissor(cX + 10, cY + 10, 120, 90)
            local pW = pData.pixelW or 16
            local pH = pData.pixelH or 16
            local scaleX = math.max(1, pW / 4)
            local scaleY = math.max(1, pH / 4)

            for _, b in ipairs(pData.blocks) do
                love.graphics.setColor(b.color.r, b.color.g, b.color.b, 1)
                love.graphics.rectangle("fill", cX + 10 + b.col * scaleX, cY + 10 + b.row * scaleY, scaleX, scaleY)
            end
            love.graphics.setScissor()
        end

        -- Title Label
        love.graphics.setColor(0.9, 0.9, 0.9)
        love.graphics.print(pName, cX + 10, cY + 110)
    end

    -- Context Menu
    if contextMenu and contextMenu.visible then
        local cmX, cmY = contextMenu.x, contextMenu.y
        love.graphics.setColor(0.25, 0.25, 0.3)
        love.graphics.rectangle("fill", cmX, cmY, 120, 60, 4, 4)
        love.graphics.setColor(0.4, 0.4, 0.5)
        love.graphics.rectangle("line", cmX, cmY, 120, 60, 4, 4)

        love.graphics.setColor(1, 1, 1)
        love.graphics.print("Edit", cmX + 15, cmY + 10)
        love.graphics.print("Delete", cmX + 15, cmY + 35)
    end
end

-- 2. Draw Naming / Options Modal
function Renderer.drawNamingModal(projectList, contextMenu, inputProjectName, cursorTimer, projectBlocks, buttonLabel)
    Renderer.drawHome(projectList, contextMenu, projectBlocks)

    love.graphics.setColor(0, 0, 0, 0.6)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())

    local mw, mh = 360, 310
    local mx = love.graphics.getWidth() / 2 - mw / 2
    local my = love.graphics.getHeight() / 2 - mh / 2

    love.graphics.setColor(0.18, 0.2, 0.24)
    love.graphics.rectangle("fill", mx, my, mw, mh, 10, 10)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Project Settings", mx + 20, my + 20)

    -- Name Field
    love.graphics.setColor(0.1, 0.12, 0.15)
    love.graphics.rectangle("fill", mx + 20, my + 50, 320, 35, 5, 5)
    love.graphics.setColor(1, 1, 1)
    local cursor = (cursorTimer > 0.5) and "|" or ""
    love.graphics.print(inputProjectName .. cursor, mx + 30, my + 60)

    -- Pixel Width Controls (- / + by 1)
    love.graphics.setColor(0.8, 0.8, 0.8)
    love.graphics.print("Pixel Width:", mx + 20, my + 105)
    
    love.graphics.setColor(0.3, 0.35, 0.45)
    love.graphics.rectangle("fill", mx + 130, my + 100, 30, 25, 4, 4)
    love.graphics.rectangle("fill", mx + 230, my + 100, 30, 25, 4, 4)
    
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("-", mx + 141, my + 105)
    love.graphics.print(tostring(Renderer.selectedPixelW) .. "px", mx + 175, my + 105)
    love.graphics.print("+", mx + 241, my + 105)

    -- Pixel Height Controls (- / + by 1)
    love.graphics.setColor(0.8, 0.8, 0.8)
    love.graphics.print("Pixel Height:", mx + 20, my + 145)
    
    love.graphics.setColor(0.3, 0.35, 0.45)
    love.graphics.rectangle("fill", mx + 130, my + 140, 30, 25, 4, 4)
    love.graphics.rectangle("fill", mx + 230, my + 140, 30, 25, 4, 4)
    
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("-", mx + 141, my + 145)
    love.graphics.print(tostring(Renderer.selectedPixelH) .. "px", mx + 175, my + 145)
    love.graphics.print("+", mx + 241, my + 145)

    -- Canvas Background Preset Controls
    love.graphics.setColor(0.8, 0.8, 0.8)
    love.graphics.print("Background:", mx + 20, my + 190)

    love.graphics.setColor(Renderer.selectedCanvasPreset == "black" and {0.2, 0.6, 1} or {0.3, 0.35, 0.45})
    love.graphics.rectangle("fill", mx + 120, my + 185, 65, 25, 4, 4)
    
    love.graphics.setColor(Renderer.selectedCanvasPreset == "white" and {0.2, 0.6, 1} or {0.3, 0.35, 0.45})
    love.graphics.rectangle("fill", mx + 192, my + 185, 65, 25, 4, 4)

    love.graphics.setColor(Renderer.selectedCanvasPreset == "transparent" and {0.2, 0.6, 1} or {0.3, 0.35, 0.45})
    love.graphics.rectangle("fill", mx + 264, my + 185, 75, 25, 4, 4)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Dark", mx + 138, my + 190)
    love.graphics.print("Light", mx + 210, my + 190)
    love.graphics.print("Clear", mx + 285, my + 190)

    -- Action Button
    love.graphics.setColor(0.2, 0.7, 0.3)
    love.graphics.rectangle("fill", mx + 20, my + 245, 320, 35, 6, 6)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print(buttonLabel or "Create", mx + 145, my + 255)
end

-- 3. Draw Grid
function Renderer.drawGrid(paletteWidth, topBarHeight, pixelW, pixelH, preset)
    local bg = (preset == "white") and {0.92, 0.92, 0.92} or {0.08, 0.08, 0.1}
    love.graphics.clear(bg[1], bg[2], bg[3])

    local gridColor = (preset == "white") and {0.8, 0.8, 0.8} or {0.18, 0.18, 0.22}
    love.graphics.setColor(gridColor[1], gridColor[2], gridColor[3])

    local winW = love.graphics.getWidth()
    local winH = love.graphics.getHeight()

    for x = paletteWidth, winW, pixelW do
        love.graphics.line(x, topBarHeight, x, winH)
    end
    for y = topBarHeight, winH, pixelH do
        love.graphics.line(paletteWidth, y, winW, y)
    end
end

-- 4. Draw Placed Blocks
function Renderer.drawBlocks(placedBlocks, paletteWidth, topBarHeight, pixelW, pixelH)
    for _, b in ipairs(placedBlocks) do
        love.graphics.setColor(b.color.r, b.color.g, b.color.b, 1)
        love.graphics.rectangle("fill", paletteWidth + b.col * pixelW, topBarHeight + b.row * pixelH, pixelW, pixelH)
    end
end

-- 5. Draw Mouse Hover Preview
function Renderer.drawHover(paletteWidth, topBarHeight, pixelW, pixelH, selectedColor)
    local mx, my = love.mouse.getPosition()
    if mx > paletteWidth and my > topBarHeight then
        local col = math.floor((mx - paletteWidth) / pixelW)
        local row = math.floor((my - topBarHeight) / pixelH)

        love.graphics.setColor(selectedColor.r, selectedColor.g, selectedColor.b, 0.5)
        love.graphics.rectangle("fill", paletteWidth + col * pixelW, topBarHeight + row * pixelH, pixelW, pixelH)
        love.graphics.setColor(1, 1, 1, 0.8)
        love.graphics.rectangle("line", paletteWidth + col * pixelW, topBarHeight + row * pixelH, pixelW, pixelH)
    end
end

-- 6. Draw Color Palette (Left Sidebar)
function Renderer.drawPalette(paletteWidth, topBarHeight, paletteColors, selectedColor, boxSize, boxPadding, scrollY)
    love.graphics.setColor(0.14, 0.14, 0.17)
    love.graphics.rectangle("fill", 0, topBarHeight, paletteWidth, love.graphics.getHeight() - topBarHeight)

    love.graphics.setScissor(0, topBarHeight, paletteWidth, love.graphics.getHeight() - topBarHeight)

    for i, col in ipairs(paletteColors) do
        local boxY = topBarHeight + boxPadding + (i - 1) * (boxSize + boxPadding) + scrollY
        
        if col == selectedColor then
            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.rectangle("line", 8, boxY - 2, boxSize + 4, boxSize + 4, 4, 4)
        end

        love.graphics.setColor(col.r, col.g, col.b, 1)
        love.graphics.rectangle("fill", 10, boxY, boxSize, boxSize, 4, 4)
    end

    local plusY = topBarHeight + boxPadding + #paletteColors * (boxSize + boxPadding) + scrollY
    love.graphics.setColor(0.25, 0.25, 0.3)
    love.graphics.rectangle("fill", 10, plusY, boxSize, boxSize, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("+", 25, plusY + 12)

    love.graphics.setScissor()
end

-- 7. Draw Top Navigation Bar
function Renderer.drawTopBar(topBarHeight, currentProjectName, saveMessageTimer, pixelW, pixelH)
    love.graphics.setColor(0.18, 0.18, 0.22)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), topBarHeight)

    -- Home Button
    love.graphics.setColor(0.3, 0.35, 0.45)
    love.graphics.rectangle("fill", 15, 8, 65, 28, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Home", 30, 14)

    -- Save PNG Button
    love.graphics.setColor(0.2, 0.6, 0.3)
    love.graphics.rectangle("fill", 90, 8, 85, 28, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Save PNG", 101, 14)

    -- Clear Canvas Button
    love.graphics.setColor(0.8, 0.2, 0.2)
    love.graphics.rectangle("fill", 185, 8, 55, 28, 4, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Clear", 195, 14)

    -- Pixel Dimensions (-1 / +1 Controls)
    love.graphics.setColor(0.3, 0.35, 0.45)
    love.graphics.rectangle("fill", 250, 8, 22, 28, 4, 4)
    love.graphics.rectangle("fill", 335, 8, 22, 28, 4, 4)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print("-", 257, 14)
    love.graphics.print("W:" .. tostring(pixelW) .. " H:" .. tostring(pixelH), 277, 14)
    love.graphics.print("+", 342, 14)

    -- Project Title
    love.graphics.setColor(0.9, 0.9, 0.9)
    love.graphics.print("Project: " .. currentProjectName, 375, 14)

    -- Toast Notification
    if saveMessageTimer > 0 then
        love.graphics.setColor(0.2, 0.8, 0.4)
        love.graphics.print("Saved to Downloads!", love.graphics.getWidth() - 170, 14)
    end
end

-- 8. Draw Color Picker Modal
function Renderer.drawColorPickerModal(pickerColor)
    love.graphics.setColor(0, 0, 0, 0.6)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())

    local mw, mh = 280, 220
    local mx = love.graphics.getWidth() / 2 - mw / 2
    local my = love.graphics.getHeight() / 2 - mh / 2

    love.graphics.setColor(0.18, 0.2, 0.24)
    love.graphics.rectangle("fill", mx, my, mw, mh, 8, 8)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Color Picker", mx + 20, my + 15)

    local channels = { { name = "R", key = "r", y = my + 50 }, { name = "G", key = "g", y = my + 85 }, { name = "B", key = "b", y = my + 120 } }
    for _, ch in ipairs(channels) do
        love.graphics.setColor(1, 1, 1)
        love.graphics.print(ch.name, mx + 20, ch.y)

        love.graphics.setColor(0.1, 0.1, 0.12)
        love.graphics.rectangle("fill", mx + 45, ch.y + 2, 200, 12, 4, 4)

        local val = pickerColor[ch.key] or 0
        love.graphics.setColor(0.3, 0.6, 1)
        love.graphics.circle("fill", mx + 45 + val * 200, ch.y + 8, 8)
    end

    love.graphics.setColor(0.2, 0.7, 0.3)
    love.graphics.rectangle("fill", mx + 15, my + 165, 75, 32, 4, 4)
    love.graphics.setColor(0.8, 0.2, 0.2)
    love.graphics.rectangle("fill", mx + 100, my + 165, 75, 32, 4, 4)
    love.graphics.setColor(0.4, 0.4, 0.4)
    love.graphics.rectangle("fill", mx + 185, my + 165, 80, 32, 4, 4)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Add", mx + 38, my + 172)
    love.graphics.print("Delete", mx + 115, my + 172)
    love.graphics.print("Cancel", mx + 203, my + 172)
end

-- 9. Export PNG Function (Directly to Downloads Folder)
function Renderer.exportPNG(placedBlocks, pixelW, pixelH, preset, filename)
    local maxCol, maxRow = 0, 0
    for _, b in ipairs(placedBlocks) do
        if b.col > maxCol then maxCol = b.col end
        if b.row > maxRow then maxRow = b.row end
    end

    local width = math.max(16, (maxCol + 1)) * pixelW
    local height = math.max(16, (maxRow + 1)) * pixelH

    local canvas = love.graphics.newCanvas(width, height)
    love.graphics.setCanvas(canvas)

    if preset == "white" then
        love.graphics.clear(1, 1, 1, 1)
    elseif preset == "black" then
        love.graphics.clear(0, 0, 0, 1)
    else
        love.graphics.clear(0, 0, 0, 0)
    end

    for _, b in ipairs(placedBlocks) do
        love.graphics.setColor(b.color.r, b.color.g, b.color.b, 1)
        love.graphics.rectangle("fill", b.col * pixelW, b.row * pixelH, pixelW, pixelH)
    end

    love.graphics.setCanvas()

    local imgData = canvas:newImageData()
    local fileData = imgData:encode("png")

    local home = os.getenv("HOME") or os.getenv("USERPROFILE") or "."
    local downloadsPath = home .. "/Downloads/" .. filename

    local file = io.open(downloadsPath, "wb")
    if file then
        file:write(fileData:getString())
        file:close()
    else
        local fallbackFile = io.open(filename, "wb")
        if fallbackFile then
            fallbackFile:write(fileData:getString())
            fallbackFile:close()
        end
    end
end

return Renderer