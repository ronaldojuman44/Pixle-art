function love.conf(t)
    t.window.title = "Pixel Art"
    t.window.resizable = true
    t.window.width = 800
    t.window.height = 600
end